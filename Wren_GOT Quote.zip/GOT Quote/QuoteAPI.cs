﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GOT_Quote
{
    class QuoteAPI // first brace
    {
        public string quote { get; set; }
        public string character { get; set; }

    }
}
