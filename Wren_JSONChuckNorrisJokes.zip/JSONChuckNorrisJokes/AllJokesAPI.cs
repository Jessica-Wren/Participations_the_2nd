﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JSONChuckNorrisJokes
{
    public class AllJokesAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllAnimalAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllCareerAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllCelebrityAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllDevAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllExplicitAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllFashionAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllFoodAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllHistoryAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllMoneyAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllMovieAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllMusicAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllPoliticalAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllReligionAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllScienceAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllSportAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }

    public class AllTravelAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }
}
